package com.marcelodonato.netflixremake.model;

public class Movie {

    private int coverUrl;

    public int getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(int coverUrl) {
        this.coverUrl = coverUrl;
    }
}
